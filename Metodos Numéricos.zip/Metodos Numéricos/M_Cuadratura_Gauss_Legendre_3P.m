function varargout = M_Cuadratura_Gauss_Legendre_3P(varargin)
% M_CUADRATURA_GAUSS_LEGENDRE_3P MATLAB code for M_Cuadratura_Gauss_Legendre_3P.fig
%      M_CUADRATURA_GAUSS_LEGENDRE_3P, by itself, creates a new M_CUADRATURA_GAUSS_LEGENDRE_3P or raises the existing
%      singleton*.
%
%      H = M_CUADRATURA_GAUSS_LEGENDRE_3P returns the handle to a new M_CUADRATURA_GAUSS_LEGENDRE_3P or the handle to
%      the existing singleton*.
%
%      M_CUADRATURA_GAUSS_LEGENDRE_3P('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in M_CUADRATURA_GAUSS_LEGENDRE_3P.M with the given input arguments.
%
%      M_CUADRATURA_GAUSS_LEGENDRE_3P('Property','Value',...) creates a new M_CUADRATURA_GAUSS_LEGENDRE_3P or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before M_Cuadratura_Gauss_Legendre_3P_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to M_Cuadratura_Gauss_Legendre_3P_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help M_Cuadratura_Gauss_Legendre_3P

% Last Modified by GUIDE v2.5 05-Jun-2016 18:43:10

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @M_Cuadratura_Gauss_Legendre_3P_OpeningFcn, ...
                   'gui_OutputFcn',  @M_Cuadratura_Gauss_Legendre_3P_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before M_Cuadratura_Gauss_Legendre_3P is made visible.
function M_Cuadratura_Gauss_Legendre_3P_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to M_Cuadratura_Gauss_Legendre_3P (see VARARGIN)

% Choose default command line output for M_Cuadratura_Gauss_Legendre_3P
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes M_Cuadratura_Gauss_Legendre_3P wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = M_Cuadratura_Gauss_Legendre_3P_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function ingreso_Callback(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ingreso as text
%        str2double(get(hObject,'String')) returns contents of ingreso as a double


% --- Executes during object creation, after setting all properties.
function ingreso_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function li_Callback(hObject, eventdata, handles)
% hObject    handle to li (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of li as text
%        str2double(get(hObject,'String')) returns contents of li as a double


% --- Executes during object creation, after setting all properties.
function li_CreateFcn(hObject, eventdata, handles)
% hObject    handle to li (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ls_Callback(hObject, eventdata, handles)
% hObject    handle to ls (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ls as text
%        str2double(get(hObject,'String')) returns contents of ls as a double


% --- Executes during object creation, after setting all properties.
function ls_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ls (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function superi_Callback(hObject, eventdata, handles)
% hObject    handle to superi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of superi as text
%        str2double(get(hObject,'String')) returns contents of superi as a double


% --- Executes during object creation, after setting all properties.
function superi_CreateFcn(hObject, eventdata, handles)
% hObject    handle to superi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in computar.
function computar_Callback(hObject, eventdata, handles)
% hObject    handle to computar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


a=str2double(get(handles.li,'String'));
b=str2double(get(handles.ls,'String'));

N=str2double(get(handles.ni,'String'))

sym x
fx1=get(handles.ingreso,'String')
fx1=inline(fx1)




ezplot(fx1);
grid on
xlabel('Valores de (x)');
ylabel('Valores de F(x)');




h = (b-a)/(N/3);                 % Tama�o del intervalo.
r = [-sqrt(3/5) 0  sqrt(3/5)];   % Ra�ces del polinomio de Legendre de orden 3.
x = ((b-a).*r+b+a)/2;            % Nodos.

t= length(x)

for k=1:t
    fx(k)=fx1(x(k));
end




k = 1;                           % Contador de iteraciones.
% Primer resultado de la integral con un solo intervalo.
IGauss3(k) = (h/2)*((5/9)*fx(1)+(8/9)*fx(2)+(5/9)*fx(3));
% Reducir el paso de integraci�n.
tol = 1;
c1=a;
c2=b;
while tol > 1e-2
    N = 2*N;                              % Duplicar el n�mero de muestras.
    h = (c2-c1)/(N/3);                    % Nuevo tama�o del intervalo.
    n = (a:h:b);                          % Determina la posici�n de los intervalos.
    x = [];                               % Inicia los nodos.
    % Ciclo para determinar los nodos en cada uno de los nuevos intervalos.
    for l = 1:length(n)-1
        c1 = n(l);                        % L�mite inferior del intervalo l.
        c2 = n(l+1);                      % L�mite superior del intervalo l.
        x = [x ((c2-c1).*r+c2+c1)/2];     % Nodos dentro del intervalo l.
    end
    fx = x.^4 + 2.*x + 8;                 % Eval�a la funci�n en todos los nodos.
    Sp = length(fx);                      % N�mero de muestras.
    k = k+1;                              % Incrementa el contador de iteraciones en 1.
    % Integral num�rica con Sp nodos
    IGauss3(k) = (h/2)*(((5/9)*sum(fx(1:3:Sp-2))+ ...
                 (8/9)*sum(fx(2:3:Sp-1))+(5/9)*sum(fx(3:3:Sp))));
    tol = abs(IGauss3(k)-IGauss3(k-1));   % Evaluaci�n de la tolerancia.
    
    set(handles.respuesta,'String',IGauss3(k));
end
% Muestra en la pantalla todas las aproximaciones.
IGauss3 
    




set(handles.iteraciones,'String',IGauss3);















% --- Executes on selection change in iteraciones.
function iteraciones_Callback(hObject, eventdata, handles)
% hObject    handle to iteraciones (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns iteraciones contents as cell array
%        contents{get(hObject,'Value')} returns selected item from iteraciones


% --- Executes during object creation, after setting all properties.
function iteraciones_CreateFcn(hObject, eventdata, handles)
% hObject    handle to iteraciones (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ni_Callback(hObject, eventdata, handles)
% hObject    handle to ni (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ni as text
%        str2double(get(hObject,'String')) returns contents of ni as a double


% --- Executes during object creation, after setting all properties.
function ni_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ni (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double


% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
