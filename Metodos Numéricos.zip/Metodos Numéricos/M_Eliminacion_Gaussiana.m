function varargout = M_Eliminacion_Gaussiana(varargin)
% M_ELIMINACION_GAUSSIANA MATLAB code for M_Eliminacion_Gaussiana.fig
%      M_ELIMINACION_GAUSSIANA, by itself, creates a new M_ELIMINACION_GAUSSIANA or raises the existing
%      singleton*.
%
%      H = M_ELIMINACION_GAUSSIANA returns the handle to a new M_ELIMINACION_GAUSSIANA or the handle to
%      the existing singleton*.
%
%      M_ELIMINACION_GAUSSIANA('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in M_ELIMINACION_GAUSSIANA.M with the given input arguments.
%
%      M_ELIMINACION_GAUSSIANA('Property','Value',...) creates a new M_ELIMINACION_GAUSSIANA or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before M_Eliminacion_Gaussiana_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to M_Eliminacion_Gaussiana_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help M_Eliminacion_Gaussiana

% Last Modified by GUIDE v2.5 01-Jun-2016 20:58:56

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @M_Eliminacion_Gaussiana_OpeningFcn, ...
                   'gui_OutputFcn',  @M_Eliminacion_Gaussiana_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before M_Eliminacion_Gaussiana is made visible.
function M_Eliminacion_Gaussiana_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to M_Eliminacion_Gaussiana (see VARARGIN)

% Choose default command line output for M_Eliminacion_Gaussiana
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes M_Eliminacion_Gaussiana wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = M_Eliminacion_Gaussiana_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function ingreso_Callback(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ingreso as text
%        str2double(get(hObject,'String')) returns contents of ingreso as a double


% --- Executes during object creation, after setting all properties.
function ingreso_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function niteraciones_Callback(hObject, eventdata, handles)
% hObject    handle to niteraciones (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of niteraciones as text
%        str2double(get(hObject,'String')) returns contents of niteraciones as a double


% --- Executes during object creation, after setting all properties.
function niteraciones_CreateFcn(hObject, eventdata, handles)
% hObject    handle to niteraciones (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function vinicial_Callback(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vinicial as text
%        str2double(get(hObject,'String')) returns contents of vinicial as a double


% --- Executes during object creation, after setting all properties.
function vinicial_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function superi_Callback(hObject, eventdata, handles)
% hObject    handle to superi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of superi as text
%        str2double(get(hObject,'String')) returns contents of superi as a double


% --- Executes during object creation, after setting all properties.
function superi_CreateFcn(hObject, eventdata, handles)
% hObject    handle to superi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in computar.
function computar_Callback(hObject, eventdata, handles)
% hObject    handle to computar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


%Calcular

A=str2double(get(handles.uitable1,'data'));
B=str2double(get(handles.uitable2,'data'));

% N�mero de inc�gnitas del sistema de ecuaciones.
N = rank(A);
% Proceso de eliminaci�n gaussiana.
for k = 1:N-1
    for m = k+1:N
        MT = -A(m,k)/A(k,k);           % Multiplicadores.
        A(m,:) = A(m,:) + MT*A(k,:);   % Modificaci�n de la matriz A.
        B(m)   = B(m)   + MT*B(k);     % Modificaci�n del vector B.
    end
end
% Proceso de sustituci�n regresiva.
x(N) = B(N)/A(N,N);
for k = N-1:-1:1
    ind = N - k;


    x(k) = 0;
    for m = 1:ind
        x(k) =  x(k) - A(k,k+m)*x(k+m);
    end
        x(k) = (B(k)+x(k))/A(k,k);
end 


 
 set(handles.respuesta,'Data',x'); 

 


 




















% --- Executes on selection change in qu.
function iteraciones_Callback(hObject, eventdata, handles)
% hObject    handle to qu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns qu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from qu


% --- Executes during object creation, after setting all properties.
function qu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function grado_Callback(hObject, eventdata, handles)
% hObject    handle to grado (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of grado as text
%        str2double(get(hObject,'String')) returns contents of grado as a double


% --- Executes during object creation, after setting all properties.
function grado_CreateFcn(hObject, eventdata, handles)
% hObject    handle to grado (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)



function po_Callback(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vinicial as text
%        str2double(get(hObject,'String')) returns contents of vinicial as a double


% --- Executes during object creation, after setting all properties.
function po_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function qo_Callback(hObject, eventdata, handles)
% hObject    handle to qo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of qo as text
%        str2double(get(hObject,'String')) returns contents of qo as a double


% --- Executes during object creation, after setting all properties.
function qo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ingreso as text
%        str2double(get(hObject,'String')) returns contents of ingreso as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)


columna=str2double(get(handles.grado,'string'));

matr=cell(columna,columna);
matr(:,:)={''};

matr2=cell(columna,1);
matr2(:,:)={''};



set(handles.uitable1,'Data',matr);
set(handles.uitable1,'ColumnEditable',true(1,columna+1));
set(handles.uitable1,'Visible','on');


set(handles.uitable2,'Data',matr2);
set(handles.uitable2,'ColumnEditable',true(1,columna+1));
set(handles.uitable2,'Visible','on');
