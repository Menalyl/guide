function varargout = M_Potenciacion(varargin)
% M_POTENCIACION MATLAB code for M_Potenciacion.fig
%      M_POTENCIACION, by itself, creates a new M_POTENCIACION or raises the existing
%      singleton*.
%
%      H = M_POTENCIACION returns the handle to a new M_POTENCIACION or the handle to
%      the existing singleton*.
%
%      M_POTENCIACION('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in M_POTENCIACION.M with the given input arguments.
%
%      M_POTENCIACION('Property','Value',...) creates a new M_POTENCIACION or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before M_Potenciacion_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to M_Potenciacion_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help M_Potenciacion

% Last Modified by GUIDE v2.5 12-Jun-2016 09:05:09

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @M_Potenciacion_OpeningFcn, ...
                   'gui_OutputFcn',  @M_Potenciacion_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before M_Potenciacion is made visible.
function M_Potenciacion_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to M_Potenciacion (see VARARGIN)

% Choose default command line output for M_Potenciacion
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes M_Potenciacion wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = M_Potenciacion_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function ingreso_Callback(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ingreso as text
%        str2double(get(hObject,'String')) returns contents of ingreso as a double


% --- Executes during object creation, after setting all properties.
function ingreso_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function niteraciones_Callback(hObject, eventdata, handles)
% hObject    handle to niteraciones (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of niteraciones as text
%        str2double(get(hObject,'String')) returns contents of niteraciones as a double


% --- Executes during object creation, after setting all properties.
function niteraciones_CreateFcn(hObject, eventdata, handles)
% hObject    handle to niteraciones (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function vinicial_Callback(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vinicial as text
%        str2double(get(hObject,'String')) returns contents of vinicial as a double


% --- Executes during object creation, after setting all properties.
function vinicial_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function superi_Callback(hObject, eventdata, handles)
% hObject    handle to superi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of superi as text
%        str2double(get(hObject,'String')) returns contents of superi as a double


% --- Executes during object creation, after setting all properties.
function superi_CreateFcn(hObject, eventdata, handles)
% hObject    handle to superi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in computar.
function computar_Callback(hObject, eventdata, handles)
% hObject    handle to computar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


%Calcular
format long g


A=str2double(get(handles.uitable1,'data'));




% Resultados del m�todo de potenciaci�n.
Nc = length(A);    % Dimensi�n de la matriz principal.
% Ciclo iterativo para calcular todos los valores y vectores propios.
for k = 1:Nc
   % Funci�n que potencia la matriz hasta obtener el valor propio de mayor m�dulo
   % y su correspondiente vector propio.
   [Ev,Ld,B] = Df_Potenciacion(A);
   Lr(k)     = Ld;    % Valor propio de mayor m�dulo.
   Ed(:,k)  = Ev;     % Vector propio asociado al valor propio de mayor m�dulo.
   A          = B;    % Nueva matriz con los valores propios restantes.
end


 
 set(handles.respuesta1,'Data',Lr'); 
 set(handles.respuesta2,'Data',Ed); 
  set(handles.respuesta3,'Data',A); 

 %set(handles.respuesta4,'Data',E4n); 
 


 %  Funci�n para calcular el valor propio de mayor m�dulo y su correspondiente vector
% propio.
function[Ev,Ld,B] = Df_Potenciacion(A);
A0 = A^2;                     % Primera elevaci�n al cuadrado.
 
A0 = A0./max(max(abs(A0)));   % Normalizaci�n.
tol = 1e-12;                  % Tolerancia de convergencia en la potenciaci�n.
mx = 1;                       %  Variable que me indica el cumplimiento de la
      % tolerancia.
% Ciclo while que potencia la matriz hasta cumplir con una tolerancia.
while mx > tol
   A1 = A0^2;                    % Primera potenciaci�n.
   A1 = A1./max(max(abs(A1)));   % Normalizaci�n.
   A0 = A1^2;                    % Segunda potenciaci�n.
   A0 = A0./max(max(abs(A0)));   % Normalizaci�n.
   mx = max(max(abs(A1-A0)));    % C�lculo del cumplimiento de la tolerancia.
end
%  La matriz A0 es proporcional a la matriz idempotente sabiendo que A0 = k*A0^2,
% donde k es el coeficiente de proporcionalidad, por tanto, k = A0./A0^2, y, en
% consecuencia, la matriz idempotente ser� Id1 = k.*A0.
k    = A0./A0^2;                     % Coeficiente de proporcionalidad.
Idem = k.*A0;                        % C�lculo de la matriz idempotente.
Ld   = A(1,:)*Idem(:,1)/Idem(1,1);   % Valor propio asociado a la idempotente.
%  El nuevo sistema de donde se calcula la siguiente matriz idempotente es B = A
%Ld1*Id1, por tanto:
B= A - Ld*Idem;
%El vector propio es proporcional a los vectores columna de la matriz idempotente.
Ev = Idem(:,1)/norm(Idem(:,1));
  
 
 


















% --- Executes on selection change in qu.
function iteraciones_Callback(hObject, eventdata, handles)
% hObject    handle to qu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns qu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from qu


% --- Executes during object creation, after setting all properties.
function qu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function grado_Callback(hObject, eventdata, handles)
% hObject    handle to grado (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of grado as text
%        str2double(get(hObject,'String')) returns contents of grado as a double


% --- Executes during object creation, after setting all properties.
function grado_CreateFcn(hObject, eventdata, handles)
% hObject    handle to grado (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)



function po_Callback(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vinicial as text
%        str2double(get(hObject,'String')) returns contents of vinicial as a double


% --- Executes during object creation, after setting all properties.
function po_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function qo_Callback(hObject, eventdata, handles)
% hObject    handle to qo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of qo as text
%        str2double(get(hObject,'String')) returns contents of qo as a double


% --- Executes during object creation, after setting all properties.
function qo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ingreso as text
%        str2double(get(hObject,'String')) returns contents of ingreso as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)


columna=str2double(get(handles.grado,'string'));

matr=cell(columna,columna);
matr(:,:)={''};


set(handles.uitable1,'Data',matr);
set(handles.uitable1,'ColumnEditable',true(1,columna+1));
set(handles.uitable1,'Visible','on');
