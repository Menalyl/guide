function varargout = M_Graeffe(varargin)
% M_GRAEFFE MATLAB code for M_Graeffe.fig
%      M_GRAEFFE, by itself, creates a new M_GRAEFFE or raises the existing
%      singleton*.
%
%      H = M_GRAEFFE returns the handle to a new M_GRAEFFE or the handle to
%      the existing singleton*.
%
%      M_GRAEFFE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in M_GRAEFFE.M with the given input arguments.
%
%      M_GRAEFFE('Property','Value',...) creates a new M_GRAEFFE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before M_Graeffe_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to M_Graeffe_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help M_Graeffe

% Last Modified by GUIDE v2.5 01-Jun-2016 18:31:38

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @M_Graeffe_OpeningFcn, ...
                   'gui_OutputFcn',  @M_Graeffe_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before M_Graeffe is made visible.
function M_Graeffe_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to M_Graeffe (see VARARGIN)

% Choose default command line output for M_Graeffe
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes M_Graeffe wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = M_Graeffe_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function ingreso_Callback(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ingreso as text
%        str2double(get(hObject,'String')) returns contents of ingreso as a double


% --- Executes during object creation, after setting all properties.
function ingreso_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function niteraciones_Callback(hObject, eventdata, handles)
% hObject    handle to niteraciones (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of niteraciones as text
%        str2double(get(hObject,'String')) returns contents of niteraciones as a double


% --- Executes during object creation, after setting all properties.
function niteraciones_CreateFcn(hObject, eventdata, handles)
% hObject    handle to niteraciones (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function vinicial_Callback(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vinicial as text
%        str2double(get(hObject,'String')) returns contents of vinicial as a double


% --- Executes during object creation, after setting all properties.
function vinicial_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function superi_Callback(hObject, eventdata, handles)
% hObject    handle to superi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of superi as text
%        str2double(get(hObject,'String')) returns contents of superi as a double


% --- Executes during object creation, after setting all properties.
function superi_CreateFcn(hObject, eventdata, handles)
% hObject    handle to superi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in computar.
function computar_Callback(hObject, eventdata, handles)
% hObject    handle to computar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


%Calcular

Coef=str2double(get(handles.uitable1,'data'));
     % N�mero de coeficientes del polinomio.
n        = length(Coef)     % Grado del polinomio.


tole=str2double(get(handles.niteraciones,'string')); 
     
%  Ejecuta el m�todo de la ra�z cuadrada de Graeffe.
[F,R]=Graeffe(Coef,n);
%  Valor de las ra�ces de mayor a menor m�dulo.
R 


set(handles.qu,'Data',F); 
 set(handles.erre,'Data',R); 


 %  Funci�n del m�todo de ra�z cuadrada de Graeffe para calcular las ra�ces de
%  polinomios con la estructura P(x)= k1*x^n + k2*x^(n-1) + ... + km*x + kn donde se
%  tiene que k1=1.
%
%  El m�todo, como tal, funciona con base en la potenciaci�n de valores; por esta
%  raz�n no se aplica a polinomios de alto orden.
%
%  La funci�n se llama de la siguiente manera:
%
%              [F,R]=Graeffe(F,n)
%
%  Entradas:
%              Fu  -- Vector de coeficientes.
%              n   -- Grado del polinomio.
%
%  Salida:
%              F  -- Matriz que contiene todos los renglones de las aproximaciones
%                    hasta la convergencia.
%              R  -- Matriz que contiene todas las aproximaciones de las ra�ces hasta
%                    la convergencia.
%
function [F,R]=Graeffe(Fu,n);
N = n-1;          % Grado del polinomio.
F(1,:) = Fu ;     % Inicia el arreglo de coeficientes.
k = 2;            % Contador para almacenar todas las iteraciones.
tol = 1;          % Inicia la tolerancia para entrar en el el ciclo while.
%  Ciclo condicional para fijar la m�xima convergencia y el valor para redondear; la
%  convergencia es diferente. Depende del grado, debido a que el m�todo utiliza en
%  forma expl�cita multiplicaciones sucesivas entre coeficientes y no se puede
%  obtener la convergencia hasta donde se quiera, pues se llega a tener sobreflujo
%  num�rico.
if N == 3
    conv = 1e-3;
    redo = 1e3;
elseif N == 4 | N == 5 | N == 6
    conv = 5e-2;
    redo = 1e2;
end
%  Inicia el ciclo iterativo para el c�lculo de ra�ces.
while tol > conv
    % Inicia el ciclo iterativo para la evaluaci�n de los nuevos coeficientes.
 
 
    for m = N:-1:0
        a = min([N-m m]);
        Ar = 0;
        for km = 1:a
            Ar = Ar + (-1)^(km)*(F(k-1,m-km+1))*(F(k-1,m+km+1));
        end
        F(k,m+1) = (-1)^(n-m)*(F(k-1,m+1)^2 + 2*Ar);
    end
    % Ciclo para calcular las aproximaciones a las ra�ces.
    rs = 1/(2.^(k-1));
    R(1,k)= abs(F(k,2)).^rs;
    for kl = 2:n-1
            disc = 1;
        for kh = 1:kl-1
            disc = disc*R(kh,k);
        end
        R(kl,k)=(1/disc)*abs(F(k,kl+1)).^rs;
    end
    % Tolerancia entre dos iteraciones consecutivas para todas las ra�ces.
    TOLER = abs(R(:,k)-R(:,k-1)); 
    tol = max(TOLER);    % El valor m�ximo de todas las tolerancias.
    k = k+1;             % Contador de iteraciones.
end
%  Valor de las ra�ces calculadas.
R = round(R*redo)/redo;  
 
 
 
 
 












% --- Executes on selection change in qu.
function iteraciones_Callback(hObject, eventdata, handles)
% hObject    handle to qu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns qu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from qu


% --- Executes during object creation, after setting all properties.
function qu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function grado_Callback(hObject, eventdata, handles)
% hObject    handle to grado (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of grado as text
%        str2double(get(hObject,'String')) returns contents of grado as a double


% --- Executes during object creation, after setting all properties.
function grado_CreateFcn(hObject, eventdata, handles)
% hObject    handle to grado (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)



function po_Callback(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vinicial as text
%        str2double(get(hObject,'String')) returns contents of vinicial as a double


% --- Executes during object creation, after setting all properties.
function po_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function qo_Callback(hObject, eventdata, handles)
% hObject    handle to qo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of qo as text
%        str2double(get(hObject,'String')) returns contents of qo as a double


% --- Executes during object creation, after setting all properties.
function qo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ingreso as text
%        str2double(get(hObject,'String')) returns contents of ingreso as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)


columna=str2double(get(handles.grado,'string'));

matr=cell(1,columna+1);
matr(:,:)={''};
set(handles.uitable1,'Data',matr);
set(handles.uitable1,'ColumnEditable',true(1,columna+1));

set(handles.uitable1,'Visible','on');
