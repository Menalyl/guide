function varargout = M_Diferencias_Divididas_De_Newton(varargin)
% M_DIFERENCIAS_DIVIDIDAS_DE_NEWTON MATLAB code for M_Diferencias_Divididas_De_Newton.fig
%      M_DIFERENCIAS_DIVIDIDAS_DE_NEWTON, by itself, creates a new M_DIFERENCIAS_DIVIDIDAS_DE_NEWTON or raises the existing
%      singleton*.
%
%      H = M_DIFERENCIAS_DIVIDIDAS_DE_NEWTON returns the handle to a new M_DIFERENCIAS_DIVIDIDAS_DE_NEWTON or the handle to
%      the existing singleton*.
%
%      M_DIFERENCIAS_DIVIDIDAS_DE_NEWTON('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in M_DIFERENCIAS_DIVIDIDAS_DE_NEWTON.M with the given input arguments.
%
%      M_DIFERENCIAS_DIVIDIDAS_DE_NEWTON('Property','Value',...) creates a new M_DIFERENCIAS_DIVIDIDAS_DE_NEWTON or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before M_Diferencias_Divididas_De_Newton_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to M_Diferencias_Divididas_De_Newton_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help M_Diferencias_Divididas_De_Newton

% Last Modified by GUIDE v2.5 05-Jun-2016 08:22:27

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @M_Diferencias_Divididas_De_Newton_OpeningFcn, ...
                   'gui_OutputFcn',  @M_Diferencias_Divididas_De_Newton_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before M_Diferencias_Divididas_De_Newton is made visible.
function M_Diferencias_Divididas_De_Newton_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to M_Diferencias_Divididas_De_Newton (see VARARGIN)

% Choose default command line output for M_Diferencias_Divididas_De_Newton
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes M_Diferencias_Divididas_De_Newton wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = M_Diferencias_Divididas_De_Newton_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function ingreso_Callback(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ingreso as text
%        str2double(get(hObject,'String')) returns contents of ingreso as a double


% --- Executes during object creation, after setting all properties.
function ingreso_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function niteraciones_Callback(hObject, eventdata, handles)
% hObject    handle to niteraciones (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of niteraciones as text
%        str2double(get(hObject,'String')) returns contents of niteraciones as a double


% --- Executes during object creation, after setting all properties.
function niteraciones_CreateFcn(hObject, eventdata, handles)
% hObject    handle to niteraciones (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function vinicial_Callback(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vinicial as text
%        str2double(get(hObject,'String')) returns contents of vinicial as a double


% --- Executes during object creation, after setting all properties.
function vinicial_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function superi_Callback(hObject, eventdata, handles)
% hObject    handle to superi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of superi as text
%        str2double(get(hObject,'String')) returns contents of superi as a double


% --- Executes during object creation, after setting all properties.
function superi_CreateFcn(hObject, eventdata, handles)
% hObject    handle to superi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in computar.
function computar_Callback(hObject, eventdata, handles)
% hObject    handle to computar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


%Calcular

x=str2double(get(handles.uitable1,'data'));
fx=str2double(get(handles.uitable2,'data'));

x=x'
fx=fx'


% N�mero de muestras.
N = length(x);
% Orden de la m�xima diferencia dividida de Newton.
P = N-1;
% Aparta espacio para el almacenamiento de x, fx y todas las diferencias divididas de 
% Newton.
Tb = zeros(N,P);
Tb = [x fx Tb];
% Rutina para crear la tabla columna por columna.
for k=1:P
    for m=1:N-k
        Num = Tb(m+1,k+1) - Tb(m,k+1);   % Diferencia en el numerador.
        Den = Tb(m+k,1) - Tb(m,1);       % Diferencia del denominador.
        Tb(m,k+2) = Num/Den;             % Coeficiente resultante de la divisi�n.
    end
end
% Los coeficientes quedan en el primer rengl�n de la columna 2 a la P+2, por tanto:
  Newton = Tb(1,2:P+2);
% Rutina que crea la matriz que contiene los coeficientes resultantes de multiplicar 
% cada t�rmino de la tabla de diferencias divididas de Newton por el polinomio de 
% grado k que lo acompa�a.
for k=1:N
    orden = x(1:k-1);               % Orden del polinomio que acompa�a al coeficiente  
% de Newton.
    Pol = Newton(k)*poly(orden);    % Obtiene los coeficientes de un polinomio de  
% orden k-1.
    Coef(k,N-k+1:N) =  Pol;        % Acomoda los coeficientes en la matriz Coef.
end
% Suma todos los t�rminos del mismo orden para crear el polinomio interpolador.
Pol = sum(Coef);
xp  = (1:0.01:18);            % Vector a evaluar en puntos entre el l�mite inferior y  
% superior.
Fxp = polyval(Pol,xp);        % Evaluaci�n de la funci�n en todos los puntos  
% propuestos.
% Gr�ficas de los puntos iniciales y el polinomio interpolador.
plot(x,fx,'o',xp,Fxp,'r');   legend('Puntos iniciales','Polinomio interpolador') 


set(handles.erre,'Data',Pol'); 

 















% --- Executes on selection change in qu.
function iteraciones_Callback(hObject, eventdata, handles)
% hObject    handle to qu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns qu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from qu


% --- Executes during object creation, after setting all properties.
function qu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function grado_Callback(hObject, eventdata, handles)
% hObject    handle to grado (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of grado as text
%        str2double(get(hObject,'String')) returns contents of grado as a double


% --- Executes during object creation, after setting all properties.
function grado_CreateFcn(hObject, eventdata, handles)
% hObject    handle to grado (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)



function po_Callback(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vinicial as text
%        str2double(get(hObject,'String')) returns contents of vinicial as a double


% --- Executes during object creation, after setting all properties.
function po_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function qo_Callback(hObject, eventdata, handles)
% hObject    handle to qo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of qo as text
%        str2double(get(hObject,'String')) returns contents of qo as a double


% --- Executes during object creation, after setting all properties.
function qo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ingreso as text
%        str2double(get(hObject,'String')) returns contents of ingreso as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)


columna=str2double(get(handles.grado,'string'));

matr=cell(1,columna);
matr(:,:)={''};
set(handles.uitable1,'Data',matr);
set(handles.uitable1,'ColumnEditable',true(1,columna+1));
set(handles.uitable1,'Visible','on');


set(handles.uitable2,'Data',matr);
set(handles.uitable2,'ColumnEditable',true(1,columna+1));
set(handles.uitable2,'Visible','on');
