function varargout = M_Jenkins_Traub(varargin)
% M_JENKINS_TRAUB MATLAB code for M_Jenkins_Traub.fig
%      M_JENKINS_TRAUB, by itself, creates a new M_JENKINS_TRAUB or raises the existing
%      singleton*.
%
%      H = M_JENKINS_TRAUB returns the handle to a new M_JENKINS_TRAUB or the handle to
%      the existing singleton*.
%
%      M_JENKINS_TRAUB('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in M_JENKINS_TRAUB.M with the given input arguments.
%
%      M_JENKINS_TRAUB('Property','Value',...) creates a new M_JENKINS_TRAUB or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before M_Jenkins_Traub_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to M_Jenkins_Traub_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help M_Jenkins_Traub

% Last Modified by GUIDE v2.5 01-Jun-2016 18:51:07

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @M_Jenkins_Traub_OpeningFcn, ...
                   'gui_OutputFcn',  @M_Jenkins_Traub_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before M_Jenkins_Traub is made visible.
function M_Jenkins_Traub_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to M_Jenkins_Traub (see VARARGIN)

% Choose default command line output for M_Jenkins_Traub
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes M_Jenkins_Traub wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = M_Jenkins_Traub_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function ingreso_Callback(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ingreso as text
%        str2double(get(hObject,'String')) returns contents of ingreso as a double


% --- Executes during object creation, after setting all properties.
function ingreso_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function niteraciones_Callback(hObject, eventdata, handles)
% hObject    handle to niteraciones (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of niteraciones as text
%        str2double(get(hObject,'String')) returns contents of niteraciones as a double


% --- Executes during object creation, after setting all properties.
function niteraciones_CreateFcn(hObject, eventdata, handles)
% hObject    handle to niteraciones (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function vinicial_Callback(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vinicial as text
%        str2double(get(hObject,'String')) returns contents of vinicial as a double


% --- Executes during object creation, after setting all properties.
function vinicial_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function superi_Callback(hObject, eventdata, handles)
% hObject    handle to superi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of superi as text
%        str2double(get(hObject,'String')) returns contents of superi as a double


% --- Executes during object creation, after setting all properties.
function superi_CreateFcn(hObject, eventdata, handles)
% hObject    handle to superi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in computar.
function computar_Callback(hObject, eventdata, handles)
% hObject    handle to computar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


%Calcular

OPR=str2double(get(handles.uitable1,'data'));
OPI=str2double(get(handles.uitable2,'data'));


 P = OPR+OPI*i;                             % Vector de coeficientes complejos.
n = length(P);                             % N�mero de coeficientes del polinomio.
Ra = [];                                   % Inicia el espacio para guardar las ra�ces.
%  Ciclo iterativo paracalcular las ra�ces del polinomio.
for k = 1:n-1
    % En la etapa uno s�lo se modifica la matriz H tomando s=0.
    [H] = EtapaUno(n,P);
    % En la etapa dos se propone una ra�z y se itera hasta la convergencia.
    S = 1e-3*exp((49/180)*pi*i);  % Se propone un valor de la ra�z a un �ngulo de 49 
                                  % grados.
                                  
                                  


 
 
 
 
  [S,H]=EtapaDos(n,P,S,H);
    % En la etapa tres se realizan 10 iteraciones sin cambiar la ra�z para forzar a
    % que una sea dominante.
    [H]=EtapaTres(n,P,S,H);
    % En la etapa dos se propone una ra�z y se itera hasta la convergencia.
    [Zr,H]=EtapaDos(n,P,S,H);
    % Hace la deflaci�n del factor simple; es decir, es la divisi�n sint�tica de P(x).
    P1(1) = P(1);
    for k=2:n;
        P1(k) = P(k) + P1(k-1)*Zr;
    end
    Q = P1(1:n-1);    % Cociente resultante de la divisi�n sint�tica.
    R = P1(n);        % Residuo resultante de la divisi�n sint�tica.
    clear P1          % Se limpia el espacio donde se realiza la divisi�n sint�tica.
    P = Q;            % Se asigna el cociente al nuevo polinomio de grado n-1.
    n = length(P);    % N�mero de coeficientes del nuevo polinomio despu�s de la
                      % deflaci�n.
    % Guarda la ra�z calculada.
    Ra = [Ra
          Zr];
end
Ra      % Las N ra�ces finales del polinomio de grado N 
 
 
 set(handles.erre,'Data',Ra); 

 
 function[H] = EtapaUno(n,P)
% Se determina la primera aproximaci�n de H(z)=P�(z).
for K = 1 : n-1
    H(K) = (n-K)*P(K)/(n-1);
end
% Realizar n iteraciones para la primera etapa.
for km = 1:10
    % Dividir -H(0)/P(0), lo que equivale a dividir  -H(n-1)/P(n).
    Td = -H(n-1)/P(n);
    H(1) = P(1);
    for kl=1:n-2
        H(n-kl) = Td*H(n-kl-1) + P(n-kl);
    end
end 





 function[S,H] = EtapaDos(n,P,S,H);
% Vector de S^n para evaluar los polinomios.
[Sp,Sh]=VectorS(S,n);
% C�lculo de -P(S)/H(s).
Td = -sum(P.*Sp)/sum(H.*Sh);
% Se actualiza la ra�z S.
S = S + Td;
% Inician las iteraciones.
for k = 1:20
    % Calcular un nuevo polinomio H(s).
    [H]=NuevoH(n,Td,S,P);
    % Vector de S^n para evaluar los polinomios,
    [Sp,Sh]=VectorS(S,n);
    % C�lculo de -P(S)/H(s).
    Td = -sum(P.*Sp)/sum(H.*Sh);
    % Se actualiza la ra�z S.
    S = S + Td;
end 
 
 
 function [H]=EtapaTres(n,P,S,H);
% Vector de S^n para evaluar los polinomios.
 
[Sp,Sh]=VectorS(S,n);
% C�lculo de -P(S)/H(s).
Td = -sum(P.*Sp)/sum(H.*Sh);
% Se realizan varias iteraciones sin cambiar la ra�z para forzar a que la de menor
% m�dulo se separe de las dem�s.
for k = 1:10
    % Calcular un nuevo polinomio H(s).
    [H]=NuevoH(n,Td,S,P);
    % C�lculo de -P(S)/H(s).
    Td = -sum(P.*Sp)/sum(H.*Sh);
end 


 
 function [Sp,Sh] = VectorS(S,n);
% Vector de S elevados a las diferentes potencia para evaluar el polinomio P(s).
Sp(n) = 1;
for k = 1:n-1
    Sp(k) = S.^(n-k);
end
% Vector de S elevados a las diferentes potencias para evaluar el polinomio H(s).
Sh = Sp(2:n);
 

function[H]=NuevoH(n,Td,S,P);
% C�lculo de la matriz auxiliar para la formaci�n de la matriz H.
Q(1)=P(1);
Pv = P(1);
for k = 2:n-1
    Pv = Pv*S + P(k);
    Q(k) = Pv;
end
% C�lculo de la nueva H.
H(1)=P(1);
for k=2:n-1
    H(k) = Td*Q(k-1) + Q(k);
end 





















% --- Executes on selection change in qu.
function iteraciones_Callback(hObject, eventdata, handles)
% hObject    handle to qu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns qu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from qu


% --- Executes during object creation, after setting all properties.
function qu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function grado_Callback(hObject, eventdata, handles)
% hObject    handle to grado (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of grado as text
%        str2double(get(hObject,'String')) returns contents of grado as a double


% --- Executes during object creation, after setting all properties.
function grado_CreateFcn(hObject, eventdata, handles)
% hObject    handle to grado (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)



function po_Callback(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vinicial as text
%        str2double(get(hObject,'String')) returns contents of vinicial as a double


% --- Executes during object creation, after setting all properties.
function po_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function qo_Callback(hObject, eventdata, handles)
% hObject    handle to qo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of qo as text
%        str2double(get(hObject,'String')) returns contents of qo as a double


% --- Executes during object creation, after setting all properties.
function qo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ingreso as text
%        str2double(get(hObject,'String')) returns contents of ingreso as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)


columna=str2double(get(handles.grado,'string'));

matr=cell(1,columna+1);
matr(:,:)={''};
set(handles.uitable1,'Data',matr);
set(handles.uitable1,'ColumnEditable',true(1,columna+1));
set(handles.uitable1,'Visible','on');


set(handles.uitable2,'Data',matr);
set(handles.uitable2,'ColumnEditable',true(1,columna+1));
set(handles.uitable2,'Visible','on');
