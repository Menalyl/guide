function varargout = ANALISIS_NUMERICO(varargin)
% ANALISIS_NUMERICO MATLAB code for ANALISIS_NUMERICO.fig
%      ANALISIS_NUMERICO, by itself, creates a new ANALISIS_NUMERICO or raises the existing
%      singleton*.
%
%      H = ANALISIS_NUMERICO returns the handle to a new ANALISIS_NUMERICO or the handle to
%      the existing singleton*.
%
%      ANALISIS_NUMERICO('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ANALISIS_NUMERICO.M with the given input arguments.
%
%      ANALISIS_NUMERICO('Property','Value',...) creates a new ANALISIS_NUMERICO or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ANALISIS_NUMERICO_OpeningFcn gets called.  c2
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ANALISIS_NUMERICO_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ANALISIS_NUMERICO

% Last Modified by GUIDE v2.5 12-Jun-2016 12:51:30

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ANALISIS_NUMERICO_OpeningFcn, ...
                   'gui_OutputFcn',  @ANALISIS_NUMERICO_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ANALISIS_NUMERICO is made visible.
function ANALISIS_NUMERICO_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ANALISIS_NUMERICO (see VARARGIN)

% Choose default command line output for ANALISIS_NUMERICO
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ANALISIS_NUMERICO wait for user response (see UIRESUME)
% uiwait(handles.figure1);





 axes('Units','Normalized','Position',[0 0 1 1]); 
[x,mmm]=imread('rojo2','jpg');
image(x),colormap(mmm),axis off,hold on 



%UIWAIT makes SOLUCION wait for user response (see UIRESUME)
 %uiwait(handles.figure1);

 
 text(150,100,'UNIVERSIDAD NACIONAL SAN CRISTOBAL','Fontname','Arial','Fontsize',12,'Fontangle','Italic', ...
'Fontweight','Bold','color',[0 0 0]);
 
 
  text(300,140,'DE HUAMANGA','Fontname','Arial','Fontsize',12,'Fontangle','Italic', ...
'Fontweight','Bold','color',[0 0 0]);
 
 
 
 
 

 text(202,602,'AN�LISIS NUM�RICO','Fontname','Arial','Fontsize',20,'Fontangle','Italic', ...
'Fontweight','Bold','color',[1 0 0]);



 text(200,600,'AN�LISIS NUM�RICO','Fontname','Arial','Fontsize',20,'Fontangle','Italic', ...
'Fontweight','Bold','color',[1 1 0]);










% --- Outputs from this function are returned to the command line.
function varargout = ANALISIS_NUMERICO_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called




% --------------------------------------------------------------------
function SDENL_Callback(hObject, eventdata, handles)
% hObject    handle to SDENL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function SDEP_Callback(hObject, eventdata, handles)
% hObject    handle to SDEP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function SDELS_Callback(hObject, eventdata, handles)
% hObject    handle to SDELS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function IYADC_Callback(hObject, eventdata, handles)
% hObject    handle to IYADC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function DEIN_Callback(hObject, eventdata, handles)
% hObject    handle to DEIN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function SDEDO_Callback(hObject, eventdata, handles)
% hObject    handle to SDEDO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function VYVP_Callback(hObject, eventdata, handles)
% hObject    handle to VYVP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)






















% --------------------------------------------------------------------
function C2_Callback(hObject, eventdata, handles)

% --------------------------------------------------------------------
function j21_Callback(hObject, eventdata, handles)
M_Biseccion




% --------------------------------------------------------------------
function j22_Callback(hObject, eventdata, handles)

M_Falsa_Suposicion



% --------------------------------------------------------------------
function j23_Callback(hObject, eventdata, handles)
M_Secante

% --------------------------------------------------------------------
function j24_Callback(hObject, eventdata, handles)
M_Punto_Fijo

% --------------------------------------------------------------------
function j25_Callback(hObject, eventdata, handles)
M_Newton_Rapshon

% --------------------------------------------------------------------
function j26_Callback(hObject, eventdata, handles)

M_Newton_Rapshon_SDENL

% --------------------------------------------------------------------
function j27_Callback(hObject, eventdata, handles)
M_Punto_Fijo_Multivariable

% --------------------------------------------------------------------
function j31_Callback(hObject, eventdata, handles)


% --------------------------------------------------------------------
function j32_Callback(hObject, eventdata, handles)
% hObject    handle to j32 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


function j33_Callback(hObject, eventdata, handles)
% hObject    handle to j32 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

M_Bairstow





% --------------------------------------------------------------------
function j34_Callback(hObject, eventdata, handles)
M_Laguerre

% --------------------------------------------------------------------
function j35_Callback(hObject, eventdata, handles)
M_Bernoulli
% --------------------------------------------------------------------
function j36_Callback(hObject, eventdata, handles)
M_Newton

% --------------------------------------------------------------------
function j37_Callback(hObject, eventdata, handles)
M_Diferencia_De_Cocientes

% --------------------------------------------------------------------
function j38_Callback(hObject, eventdata, handles)
M_Graeffe

% --------------------------------------------------------------------
function j39_Callback(hObject, eventdata, handles)
M_Jenkins_Traub

% --------------------------------------------------------------------
function j41_Callback(hObject, eventdata, handles)
M_Eliminacion_Gaussiana


% --------------------------------------------------------------------
function j42_Callback(hObject, eventdata, handles)
M_Eliminacion_Gauss_Jordan


% --------------------------------------------------------------------
function j43_Callback(hObject, eventdata, handles)
M_Inversa_De_Una_Matriz

% --------------------------------------------------------------------
function j44_Callback(hObject, eventdata, handles)
M_Inversa_De_Una_Matriz_Pivoteo_Parcial


% --------------------------------------------------------------------
function j45_Callback(hObject, eventdata, handles)
M_Inversa_De_Una_Matriz_Pivoteo_Total


% --------------------------------------------------------------------
function j46_Callback(hObject, eventdata, handles)
M_Factorizacion_LU


% --------------------------------------------------------------------
function j47_Callback(hObject, eventdata, handles)
M_Factorizacion_Doolittle_Crout

% --------------------------------------------------------------------
function j48_Callback(hObject, eventdata, handles)
M_Cholesky
% --------------------------------------------------------------------
function j49_Callback(hObject, eventdata, handles)
M_Factorizacion_QR

% --------------------------------------------------------------------
function j410_Callback(hObject, eventdata, handles)
M_Jacobi

% --------------------------------------------------------------------
function j411_Callback(hObject, eventdata, handles)
M_Gauss_Seidel

% --------------------------------------------------------------------
function j412_Callback(hObject, eventdata, handles)
M_Ecuaciones_Subdeterminado

% --------------------------------------------------------------------
function j413_Callback(hObject, eventdata, handles)
M_Ecuaciones_Sobredeterminado

% --------------------------------------------------------------------
function j81_Callback(hObject, eventdata, handles)
M_Householder

% --------------------------------------------------------------------
function j82_Callback(hObject, eventdata, handles)
M_Multiplicacion_Sucesiva_Por_Yk

% --------------------------------------------------------------------
function j83_Callback(hObject, eventdata, handles)
M_Potenciacion

% --------------------------------------------------------------------
function j63_Callback(hObject, eventdata, handles)
M_Regla_Trapezoidal

% --------------------------------------------------------------------
function j72_Callback(hObject, eventdata, handles)
% hObject    handle to j72 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function j73_Callback(hObject, eventdata, handles)
% hObject    handle to j73 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function j74_Callback(hObject, eventdata, handles)
% hObject    handle to j74 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function j75_Callback(hObject, eventdata, handles)
% hObject    handle to j75 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function j76_Callback(hObject, eventdata, handles)
M_Explicito_Para_m1

% --------------------------------------------------------------------
function j77_Callback(hObject, eventdata, handles)
M_Explicito_Para_m2

% --------------------------------------------------------------------
function j78_Callback(hObject, eventdata, handles)
M_Explicito_Para_m3

% --------------------------------------------------------------------
function j79_Callback(hObject, eventdata, handles)
M_Multipaso_Lineal

% --------------------------------------------------------------------
function j710_Callback(hObject, eventdata, handles)
% hObject    handle to j710 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function j711_Callback(hObject, eventdata, handles)
% hObject    handle to j711 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function j61_Callback(hObject, eventdata, handles)
M_Regla_Rectangular_Izquierda

% --------------------------------------------------------------------
function j62_Callback(hObject, eventdata, handles)
M_Regla_Rectangular_Derecha



% --------------------------------------------------------------------
function j64_Callback(hObject, eventdata, handles)

M_Integracion_De_Simpson13




% --------------------------------------------------------------------
function j65_Callback(hObject, eventdata, handles)
M_Integracion_De_Simpson38

% --------------------------------------------------------------------
function j66_Callback(hObject, eventdata, handles)
M_Integracion_De_Punto_Medio

% --------------------------------------------------------------------
function j67_Callback(hObject, eventdata, handles)
%M_Cuadratura_Gauss_Legendre_2P

% --------------------------------------------------------------------
function j68_Callback(hObject, eventdata, handles)
% hObject    handle to j68 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function j69_Callback(hObject, eventdata, handles)
M_Integracion_De_Romberg



% --------------------------------------------------------------------
function j51_Callback(hObject, eventdata, handles)
M_Vandermonde

% --------------------------------------------------------------------
function j52_Callback(hObject, eventdata, handles)
M_Lagrange

% --------------------------------------------------------------------
function j53_Callback(hObject, eventdata, handles)
M_Diferencias_Divididas_De_Newton

% --------------------------------------------------------------------
function j54_Callback(hObject, eventdata, handles)
M_Minimos_Cuadrados

% --------------------------------------------------------------------
function j55_Callback(hObject, eventdata, handles)
M_Transformada_Discreta_De_Fourier

% --------------------------------------------------------------------
function j56_Callback(hObject, eventdata, handles)
M_Ajuste_De_Tchebyshev

% --------------------------------------------------------------------
function j57_Callback(hObject, eventdata, handles)
M_Lagrange_Tchebyshev

% --------------------------------------------------------------------
function C3_Callback(hObject, eventdata, handles)
% hObject    handle to C3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function C4_Callback(hObject, eventdata, handles)
% hObject    handle to C4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function C5_Callback(hObject, eventdata, handles)
% hObject    handle to C5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function C6_Callback(hObject, eventdata, handles)
% hObject    handle to C6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function C7_Callback(hObject, eventdata, handles)
% hObject    handle to C7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function C8_Callback(hObject, eventdata, handles)
% hObject    handle to C8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------


% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
Integrantes
