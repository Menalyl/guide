function varargout = M_Ajuste_De_Tchebyshev(varargin)
% M_AJUSTE_DE_TCHEBYSHEV MATLAB code for M_Ajuste_De_Tchebyshev.fig
%      M_AJUSTE_DE_TCHEBYSHEV, by itself, creates a new M_AJUSTE_DE_TCHEBYSHEV or raises the existing
%      singleton*.
%
%      H = M_AJUSTE_DE_TCHEBYSHEV returns the handle to a new M_AJUSTE_DE_TCHEBYSHEV or the handle to
%      the existing singleton*.
%
%      M_AJUSTE_DE_TCHEBYSHEV('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in M_AJUSTE_DE_TCHEBYSHEV.M with the given input arguments.
%
%      M_AJUSTE_DE_TCHEBYSHEV('Property','Value',...) creates a new M_AJUSTE_DE_TCHEBYSHEV or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before M_Ajuste_De_Tchebyshev_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to M_Ajuste_De_Tchebyshev_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help M_Ajuste_De_Tchebyshev

% Last Modified by GUIDE v2.5 20-Jul-2016 21:43:54

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @M_Ajuste_De_Tchebyshev_OpeningFcn, ...
                   'gui_OutputFcn',  @M_Ajuste_De_Tchebyshev_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before M_Ajuste_De_Tchebyshev is made visible.
function M_Ajuste_De_Tchebyshev_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to M_Ajuste_De_Tchebyshev (see VARARGIN)

% Choose default command line output for M_Ajuste_De_Tchebyshev
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes M_Ajuste_De_Tchebyshev wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = M_Ajuste_De_Tchebyshev_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function ingreso_Callback(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ingreso as text
%        str2double(get(hObject,'String')) returns contents of ingreso as a double


% --- Executes during object creation, after setting all properties.
function ingreso_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function niteraciones_Callback(hObject, eventdata, handles)
% hObject    handle to niteraciones (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of niteraciones as text
%        str2double(get(hObject,'String')) returns contents of niteraciones as a double


% --- Executes during object creation, after setting all properties.
function niteraciones_CreateFcn(hObject, eventdata, handles)
% hObject    handle to niteraciones (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function vinicial_Callback(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vinicial as text
%        str2double(get(hObject,'String')) returns contents of vinicial as a double


% --- Executes during object creation, after setting all properties.
function vinicial_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function superi_Callback(hObject, eventdata, handles)
% hObject    handle to superi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of superi as text
%        str2double(get(hObject,'String')) returns contents of superi as a double


% --- Executes during object creation, after setting all properties.
function superi_CreateFcn(hObject, eventdata, handles)
% hObject    handle to superi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in computar.
function computar_Callback(hObject, eventdata, handles)
% hObject    handle to computar (see GCBO)

format long g


a=str2double(get(handles.limiteinferuior,'String'));
b=str2double(get(handles.limitesuperior,'String'));
N=str2double(get(handles.nmuestras,'String'));



% Orden del polinomio.
P = N-1;
% Se crea en forma inicial una celda de NMUESTRAS espacios para almacenar el polinomio de 
% Tchebyshev.
T = cell(1,N);
% Inicia los dos primeros polinomios de Tchebyshev y los acomoda en su respectiva 
% celda.
T(1:2) = { [1], [1 0] };
% Relaci�n de recurrencia para calcular los coeficientes de Tchebyshev, en este caso 
% los almacena en celdas de dimensi�n adecuada de acuerdo al orden del polinomio.
for k = 2:N-1
    T{k+1} = [2*T{k} 0] - [0 0 T{k-1}];
end
% Coeficientes de los polinomios a utilizar en el ajuste.
Tchebyshev(N,N) = zeros;
for k=1:N
    Tchebyshev(k,1:k)=T{k};
end
Tshe = Tchebyshev.';
% C�lculo de los puntos de ortogonalidad para el ajuste de Tchebyshev.
x = (cos(((N-1:-1:0)* pi)/(N-1))).';
% Cambio de los puntos de ortogonalidad al intervalo [a=8 b=12] con la f�rmula 
% z=(1/2)[(b-a)x + b + a].
  z = (1/2).*((b-a).* x + b + a);
% Evaluaci�n de la funci�n en los puntos de ortogonalidad trasladados.
fz = 2.*z - z.^2 + z.^3.*sin(z).*exp(-z./10);
% C�lculo de la matriz de datos Shev que contiene
% |  z  |  fz  |  x  |  To(x)  |  T1(x)  |  ....  |  Tn(x)  |
Shev = [];              % Inicia la variable en vac�o [].


Shev = [Shev z fz x];   % Sobre la matriz de datos por z, fz y x.
Pe = [];                 % Inicia la evaluaci�n de los polinomios de Tchebyshev en  
% vac�o [].
% Ciclo para evaluar num�ricamente los polinomios de Tchebyshev.
for l = 1:N
    Ren(N,N)=zeros;      % Esta variable almacena la variable x elevada a todas las  
% potencias, desde o hasta NMUESTRAS-1.
    for k=1:N
        for m=k:-1:1
            Ren(m,k)=x(l).^(k-m);
        end
    end
    M = Tshe.*Ren;       % Se hace la multiplicaci�n de los coeficientes por la  
% variable x correspondiente.
    C = (sum(M));        % Se suma el resultado de cada t�rmino de los polinomios para 
% tener su evaluaci�n num�rica.
    Pe = [Pe; C];        % El resultado de cada polinomio evaluado se guarda en una  
% matriz Pe.
end
Shev = [Shev Pe];       % Finalmente se le agrega a la matriz de datos Shev.
% Rutina para calcular los coeficientes B.
B = (2/(N-1)).* Shev(1,2)*Shev(1,4:3+N)/2;
for k=2:N-1
    B = B + (2/(N-1)) .* Shev(k,2).*Shev(k,4:3+N);
end
B = B + (2/(N-1)) .* Shev(N,2)*Shev(N,4:3+N)/2;
% Rutina para el c�lculo de los coeficientes A.
A(1)=B(1)/2;    
A(2:N-1) = B(2:N-1);
A(N)= B(N)/2;
% Rutina para calcular los coeficientes que acompa�an los polinomios de Tchebyshev.
for k=1:N
    CO(:,k) = A(k)*Tshe(:,k);
end
% Rutina para calcular los coeficientes del polinomio interpolador.
for k=1:N
    Coef(k) = sum(diag(CO,k-1));
end
% Polinomio interpolador de Tchebyshev evaluado en el intervalo [-1, +1].
w = -1:0.01:1;
fx = 0;
for k=1:N
    fx = fx + Coef(k)*w.^(k-1);
end
% Se transportan los puntos del intervalo [-1,+1] al intervalo de inter�s [a,b].
q  = (1/2).*((b-a).*w + b + a);
% Evaluaci�n de la funci�n anal�tica (como punto de comparaci�n) en los puntos de  
% ortogonalidad trasladados.
fq = 2.*q - q.^2 + q.^3.*sin(q).*exp(-q./10);
% Gr�fica de los puntos utilizados para hacer el polinomio interpolador, de la 
% funci�n anal�tica evaluada y del polinomio interpolador de Tchebyshev.
plot(z,fz,'o',q,fx,'r',q,fq,'--');
legend('Puntos utilizados para crear el interpolador','Interpolador de Tchebyshev','Funci�n anal�tica')





set(handles.calculado,'Data',Coef'); 

 


% --- Executes on selection change in qu.
function iteraciones_Callback(hObject, eventdata, handles)
% hObject    handle to qu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns qu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from qu


% --- Executes during object creation, after setting all properties.
function qu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function grado_Callback(hObject, eventdata, handles)
% hObject    handle to grado (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of grado as text
%        str2double(get(hObject,'String')) returns contents of grado as a double


% --- Executes during object creation, after setting all properties.
function grado_CreateFcn(hObject, eventdata, handles)
% hObject    handle to grado (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)



function po_Callback(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vinicial as text
%        str2double(get(hObject,'String')) returns contents of vinicial as a double


% --- Executes during object creation, after setting all properties.
function po_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function qo_Callback(hObject, eventdata, handles)
% hObject    handle to qo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of qo as text
%        str2double(get(hObject,'String')) returns contents of qo as a double


% --- Executes during object creation, after setting all properties.
function qo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ingreso as text
%        str2double(get(hObject,'String')) returns contents of ingreso as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)


columna=str2double(get(handles.grado,'string'));

matr=cell(1,columna);
matr(:,:)={''};


set(handles.uitable2,'Data',matr);
set(handles.uitable2,'ColumnEditable',true(1,columna+1));
set(handles.uitable2,'Visible','on');



function limiteinferuior_Callback(hObject, eventdata, handles)
% hObject    handle to limiteinferuior (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of limiteinferuior as text
%        str2double(get(hObject,'String')) returns contents of limiteinferuior as a double


% --- Executes during object creation, after setting all properties.
function limiteinferuior_CreateFcn(hObject, eventdata, handles)
% hObject    handle to limiteinferuior (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function limitesuperior_Callback(hObject, eventdata, handles)
% hObject    handle to limitesuperior (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of limitesuperior as text
%        str2double(get(hObject,'String')) returns contents of limitesuperior as a double


% --- Executes during object creation, after setting all properties.
function limitesuperior_CreateFcn(hObject, eventdata, handles)
% hObject    handle to limitesuperior (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function nmuestras_Callback(hObject, eventdata, handles)
% hObject    handle to nmuestras (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of nmuestras as text
%        str2double(get(hObject,'String')) returns contents of nmuestras as a double


% --- Executes during object creation, after setting all properties.
function nmuestras_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nmuestras (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
