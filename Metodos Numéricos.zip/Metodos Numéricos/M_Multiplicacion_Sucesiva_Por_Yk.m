function varargout = M_Multiplicacion_Sucesiva_Por_Yk(varargin)
% M_MULTIPLICACION_SUCESIVA_POR_YK MATLAB code for M_Multiplicacion_Sucesiva_Por_Yk.fig
%      M_MULTIPLICACION_SUCESIVA_POR_YK, by itself, creates a new M_MULTIPLICACION_SUCESIVA_POR_YK or raises the existing
%      singleton*.
%
%      H = M_MULTIPLICACION_SUCESIVA_POR_YK returns the handle to a new M_MULTIPLICACION_SUCESIVA_POR_YK or the handle to
%      the existing singleton*.
%
%      M_MULTIPLICACION_SUCESIVA_POR_YK('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in M_MULTIPLICACION_SUCESIVA_POR_YK.M with the given input arguments.
%
%      M_MULTIPLICACION_SUCESIVA_POR_YK('Property','Value',...) creates a new M_MULTIPLICACION_SUCESIVA_POR_YK or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before M_Multiplicacion_Sucesiva_Por_Yk_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to M_Multiplicacion_Sucesiva_Por_Yk_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help M_Multiplicacion_Sucesiva_Por_Yk

% Last Modified by GUIDE v2.5 12-Jun-2016 09:00:22

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @M_Multiplicacion_Sucesiva_Por_Yk_OpeningFcn, ...
                   'gui_OutputFcn',  @M_Multiplicacion_Sucesiva_Por_Yk_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before M_Multiplicacion_Sucesiva_Por_Yk is made visible.
function M_Multiplicacion_Sucesiva_Por_Yk_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to M_Multiplicacion_Sucesiva_Por_Yk (see VARARGIN)

% Choose default command line output for M_Multiplicacion_Sucesiva_Por_Yk
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes M_Multiplicacion_Sucesiva_Por_Yk wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = M_Multiplicacion_Sucesiva_Por_Yk_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function ingreso_Callback(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ingreso as text
%        str2double(get(hObject,'String')) returns contents of ingreso as a double


% --- Executes during object creation, after setting all properties.
function ingreso_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function niteraciones_Callback(hObject, eventdata, handles)
% hObject    handle to niteraciones (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of niteraciones as text
%        str2double(get(hObject,'String')) returns contents of niteraciones as a double


% --- Executes during object creation, after setting all properties.
function niteraciones_CreateFcn(hObject, eventdata, handles)
% hObject    handle to niteraciones (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function vinicial_Callback(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vinicial as text
%        str2double(get(hObject,'String')) returns contents of vinicial as a double


% --- Executes during object creation, after setting all properties.
function vinicial_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function superi_Callback(hObject, eventdata, handles)
% hObject    handle to superi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of superi as text
%        str2double(get(hObject,'String')) returns contents of superi as a double


% --- Executes during object creation, after setting all properties.
function superi_CreateFcn(hObject, eventdata, handles)
% hObject    handle to superi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in computar.
function computar_Callback(hObject, eventdata, handles)
% hObject    handle to computar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


%Calcular

A=str2double(get(handles.uitable1,'data'));


A0 = A;                       % Asignaci�n de la matriz a otra variable.
yp = [1;7;54];                % Vector inicial para la multiplicaci�n sucesiva.
N  = rank(A);                 % N�mero de variables del sistema original.
Nt = 1;                       % Variable utilizada para iniciar la convergencia.
To = 1e-12;                   % Tolerancia utilizada para la convergencia.
% Ciclo para el c�lculo de los tres valores propios.
for k = 1:N
    % Ciclo de convergencia.
    while Nt > To
        m = max(abs(yp));   % M�ximo valor para normalizar el vector.
        yp = yp./m;         % Normalizaci�n del vector yp.
        y1 = A*yp;          % Multiplicaci�n sucesiva de la matriz A por yp.
        mt = max(abs(y1));  % M�ximo valor de y1.
        Nt = abs(m-mt);     %  C�lculo de la diferencia entre dos soluciones
    % consecutivas.
        yp = y1;            % Asignaci�n del vector nuevo a la variable.
    end
    yp = yp./m;                  % Normalizaci�n del vector yp.
    [Ym,Pos] = (max(abs(yp)));   % Se busca el valor m�ximo de yp y la posici�n.
    Ac = A - yp*A(Pos,:) ;       %  Se calcula la siguiente matriz, la cual tiene un
         % valor propio igual a cero.
    A = Ac;                      % Se reasigna la matriz.
    Ep(:,k) = yp;                % Se guarda el vector propio.
    Epn(:,k) = yp/norm(yp);      % Se normaliza el vector propio.
    Ez(k,1) = m;                 % Se guarda el valor propio.
    XY(k,1) = Pos;               % Se guarda la posici�n del valor propio k.
    if k == 1                    % Esta condici�n es para guardar la segunda matriz,

       A1 = A;                   % se guarda de esta manera.
    end
    Nt = 1;                      % Variable utilizada para iniciar la convergencia.
end
% C�lculo del segundo vector propio.
k1=(Ez(1)-Ez(2))/(A0(XY(1),:)*Ep(:,2));  % Se calcula la constante para referir el
           % c�lculo a la matriz original.
E2 = Ep(:,1)-k1*Ep(:,2);                 %  Se calcula el vector propio referido a la
           % matriz original.
E2n = E2/norm(E2);                       % Se normaliza el vector propio.
% C�lculo del tercer vector propio.
k2 = (Ez(2)-Ez(3))/(A(XY(3),:)*Ep(:,3)); % Se calcula la constante para referir el
           % c�lculo a la matriz anterior.
E3 = Ep(:,2)-k2*Ep(:,3);                 %  Se calcula el vector propio referido a la
           % matriz anterior.
E3n = E3/norm(E3);                       % Se normaliza el vector propio.
k3 = (Ez(1)-Ez(2))/(A0(XY(2),:)*E3n);    % Se calcula la constante para referir el
           % c�lculo a la matriz original.
E4 = Ep(:,1)-k3*E3n;                     %  Se calcula el vector propio referido a la
           % matriz original.
E4n = E4/norm(E4);                       % Se normaliza el vector propio.
% Los valores propios son, por tanto,
Ez
% Los vectores propios son a su vez
Epn(:,1)
E2n
E4n 
        
        
        
        
 
 set(handles.respuesta1,'Data',Ez); 
 set(handles.respuesta2,'Data',Epn(:,1)); 
  set(handles.respuesta3,'Data',E2n); 

 set(handles.respuesta4,'Data',E4n); 
 




















% --- Executes on selection change in qu.
function iteraciones_Callback(hObject, eventdata, handles)
% hObject    handle to qu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns qu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from qu


% --- Executes during object creation, after setting all properties.
function qu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function grado_Callback(hObject, eventdata, handles)
% hObject    handle to grado (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of grado as text
%        str2double(get(hObject,'String')) returns contents of grado as a double


% --- Executes during object creation, after setting all properties.
function grado_CreateFcn(hObject, eventdata, handles)
% hObject    handle to grado (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)



function po_Callback(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vinicial as text
%        str2double(get(hObject,'String')) returns contents of vinicial as a double


% --- Executes during object creation, after setting all properties.
function po_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vinicial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function qo_Callback(hObject, eventdata, handles)
% hObject    handle to qo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of qo as text
%        str2double(get(hObject,'String')) returns contents of qo as a double


% --- Executes during object creation, after setting all properties.
function qo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ingreso as text
%        str2double(get(hObject,'String')) returns contents of ingreso as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ingreso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)


columna=str2double(get(handles.grado,'string'));

matr=cell(columna,columna);
matr(:,:)={''};


set(handles.uitable1,'Data',matr);
set(handles.uitable1,'ColumnEditable',true(1,columna+1));
set(handles.uitable1,'Visible','on');
